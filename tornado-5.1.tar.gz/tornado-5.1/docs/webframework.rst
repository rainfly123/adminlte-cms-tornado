Web framework
=============

.. toctree::

   web
   template
   routing
   escape
   locale
   websocket
